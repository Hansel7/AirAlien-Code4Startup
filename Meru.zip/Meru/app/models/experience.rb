class Experience < ApplicationRecord
  belongs_to :user
  has_many :photos 
  has_many :reservations
   has_many :reviews

  geocoded_by :address
  after_validation :geocode, if: :meeting_point_changed?

  validates :experience_title, presence: true, length: {maximum: 50}
  validates :experience_type, presence: true
  validates :start_time, presence: true
  validates :end_time, presence: true
  validates :tagline, presence: true, length: {maximum: 50}
  validates :what_youll_experience, presence: true  
  validates :itinerary, presence: true
  validates :meeting_point, presence: true
  validates :inclusions, presence: false
  validates :requirements, presence: false
  validates :details, presence: false
  validates :price, presence: true

  def average_rating
    reviews.count == 0 ? 0 : reviews.average(:star).round(2) 
  end   

end
