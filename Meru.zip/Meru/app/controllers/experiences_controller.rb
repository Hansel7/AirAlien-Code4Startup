class ExperiencesController < ApplicationController
  before_action :set_experience, only: [:show, :edit, :update]
  before_action :authenticate_user!, except: [:show]
  
  def index
    @experiences = current_user.experiences
  end

  def show
    @photos = @experience.photos
    
    @booked = Reservation.where("experience_id = ? AND user_id = ?", @experience.id, current_user.id).present? if current_user
    
    @reviews = @experience.reviews
    @hasReview = @reviews.find_by(user_id: current_user.id) if current_user
  end

  def new
    @experience = current_user.experiences.build    
  end

  def create
    @experience = current_user.experiences.build(experience_params)

    if @experience.save

      if params[:images]
        params[:images].each do |image|
          @experience.photos.create(image: image)
        end 
      end   
      
      @photos = @experience.photos 
      redirect_to edit_experience_path(@experience), notice: "Saved..."
    else
      render :new
    end  
  end

  def edit
    if current_user.id == @experience.user.id 
      @photos = @experience.photos
    else 
      redirect_to root_path, notice: "You don't have permission."
    end
  end   

  def update
    if @experience.update(experience_params)

      if params[:images]
        params[:images].each do |image|
          @experience.photos.create(image: image)
        end 
      end   
      
      redirect_to edit_experience_path(@experience), notice: "Updated..."
    else 
      render :edit  
  end
end
  private 
    def set_experience
      @experience = Experience.find(params[:id])
    end 

    def experience_params
      params.require(:experience).permit(:experience_title, :experience_type, :start_time, :end_time, :tagline, :what_youll_experience, :itinerary, :meeting_point, :inclusions, :requirements, :details, :group_size_min, :group_size_max, :is_guide, :is_transport, :is_food, :is_shelter, :is_equipment, :price, :active)
  end
end        