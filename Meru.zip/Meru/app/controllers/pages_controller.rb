class PagesController < ApplicationController
  def home
  	@experiences = Experience.limit(6) 
  end
    def search

  	if params[:search].present? && params[:search].strip != ""
  		session[:loc_search] = params[:search]
  	end

  	arrResult = Array.new

  	if session[:loc_search] && session[:loc_search] != ""
  		@experiences_meeting_point = Experience.where(active: true).near(session[:loc_search], 5, order: 'distance')
  	else
  		@experiences_meeting_point = Experience.where(active: true).all
  	end

  	@search = @experiences_meeting_point.ransack(params[:q])
  	@experiences = @search.result

  	@arrExperiences = @experiences.to_a

  	if (params[:start_date] && params[:end_date] && !params[:start_date].empty? & !params[:end_date].empty?)

  		start_date = Date.parse(params[:start_date])
  		end_date = Date.parse(params[:end_date])

  		@experiences.each do |experience|

  			not_available = experience.reservations.where(
  					"(? <= start_date AND start_date <= ?)
  					OR (? <= end_date AND end_date <= ?) 
  					OR (start_date < ? AND ? < end_date)",
  					start_date, end_date,
  					start_date, end_date,
  					start_date, end_date
  				).limit(1)

  			if not_available.length > 0
  				@arrExperiences.delete(experience)	
  			end	

  		end

  	end    	

end
end
