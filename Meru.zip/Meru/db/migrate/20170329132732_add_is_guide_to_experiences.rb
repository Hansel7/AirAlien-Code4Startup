class AddIsGuideToExperiences < ActiveRecord::Migration[5.0]
  def change
    add_column :experiences, :is_guide, :boolean
  end
end
