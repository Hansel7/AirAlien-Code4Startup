class AddIsEquipmentToExperiences < ActiveRecord::Migration[5.0]
  def change
    add_column :experiences, :is_equipment, :boolean
  end
end
