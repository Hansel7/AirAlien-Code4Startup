class CreateExperiences < ActiveRecord::Migration[5.0]
  def change
    create_table :experiences do |t|
      t.string :experience_title
      t.string :experience_type
      t.integer :start_time
      t.integer :end_time
      t.integer :tagline
      t.text :what_youll_experience
      t.text :itinerary
      t.integer :meeting_point
      t.string :inclusions
      t.text :requirements
      t.text :details
      t.integer :price
      t.boolean :active
      t.references :user, foreign_key: true

      t.timestamps null: false 
    end
    end 
  end
end
