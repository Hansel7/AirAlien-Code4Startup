class AddIsShelterToExperiences < ActiveRecord::Migration[5.0]
  def change
    add_column :experiences, :is_shelter, :boolean
  end
end
