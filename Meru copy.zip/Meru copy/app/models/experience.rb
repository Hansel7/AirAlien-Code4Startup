class Experience < ApplicationRecord
  belongs_to :user
  has_many :photos

  validates :experience_title, presence: true, length: {maximum: 50}
  validates :experience_type, presence: true
  validates :start_time, presence: true
  validates :end_time, presence: true
  validates :tagline, presence: true, length: {maximum: 50}
  validates :what_youll_experience, presence: true  
  validates :itinerary, presence: true
  validates :meeting_point, presence: true
  validates :inclusions, presence: true
  validates :requirements, presence: true
  validates :details, presence: true
  validates :price, presence: true

end
